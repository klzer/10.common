// JavaScript Document

//饼图	
	var pieChart={
		
		doChart : function(id,pieData1,pieName1){
			$('#'+id).highcharts({
				chart: {
					plotBackgroundColor: null,
					plotBorderWidth: null,
					plotShadow: false
				},
				title: {
					text: ''
				},
				tooltip: {
					pointFormat: '{series.name}: {point.total}(<b>{point.percentage:.1f}%</b>)'
				},
				credits: {
					enabled:false
				},
				exporting: {
					enabled:false
				},
				plotOptions: {
					pie: {
						allowPointSelect: true,
						cursor: 'pointer',
						dataLabels: {
							enabled: true,
							color: '#000000',
							connectorColor: '#000000',
							format: '<b>{point.name}</b>:{point.total}({point.percentage:.1f} %)',
							//enabled: false
							backgroundColor:'#ff0000'
						}
					}
				},
				colors:[
					'#188ec5',
					'#54b23b',
					'#ea5629',
					'#ddde30', 
					'#33cbe3',
					'#69e377', 
					'#77a1e5', 
					'#c42525', 
					'#fd5607',
					'#a6c96a'
				],
				series: [{
					type: 'pie',
					name: pieName1,
					data: pieData1
				}]
			});
		}		
				
	}