// JavaScript Document
//饼图
var dyfbPie={
		
	pieData1 :  [
				{value:100, name:'福建'},
				{value:200, name:'辽宁'},
				{value:300, name:'黑龙江'},
				{value:400, name:'广东'},
				{value:500, name:'北京'},
				{value:600, name:'天津'},
				{value:700, name:'新疆'},
				{value:800, name:'甘肃'},
				{value:900, name:'内蒙古'},
				{value:1000, name:'其他地区'}
				],
	legendData: ['福建','辽宁','黑龙江','广东','北京','天津','新疆','甘肃','内蒙古','其他地区'],			
				
	pieName1 : '访客数'		
	
};

