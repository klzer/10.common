// JavaScript Document

var echartsPie={
		
	doChart : function(id,legendData,pieData1,pieName1){

	require.config({
			paths: {
				echarts: '../js'
			}
		});
	
	require(
		[
			'echarts',
			'echarts/chart/pie' // 使用饼图就加载bar模块，按需加载
		],
		function (ec) {
			// 基于准备好的dom，初始化echarts图表
			var myChart = ec.init(document.getElementById(id)); 
			
			option = {
				title : {
					text: '',
					subtext: '',
					x:'center'
				},
				
				//backgroundColor: '#ff0000',
				tooltip : {
					trigger: 'item',
					axisPointer: {
						type:'shadow'
					},
					showDelay:20,
					//position: ['50%','50%'],
					formatter: "{a} <br/>{b} : {c} ({d}%)"
				},
				legend: {
					show:false,
					orient : 'vertical',
					x : 'left',
					data:legendData
				},
				toolbox: {
					show : false,
					feature : {
						mark : {show: true},
						dataView : {show: true, readOnly: false},
						magicType : {
							show: true, 
							type: ['pie', 'funnel'],
							option: {
								funnel: {
									x: '20%',
									width: '80%',
									funnelAlign: 'left',
									max: 1548
								}
							}
						},
						restore : {show: true},
						saveAsImage : {show: true}
					}
				},
				calculable : false,
				series : [
					{
						name: pieName1,
						type:'pie',
						radius : '70%',
						center: ['35%', '50%'],					
						itemStyle : {
							normal : {
								label : {
									show : false
								},
								labelLine : {
									show : false
								}
							},
							emphasis : {
								label : {
									show : false,
									position : 'center',
									textStyle : {
										fontSize : '30',
										fontWeight : 'bold'
									}
								}
							}
						},
						data: pieData1//[
							//{value:335, name:'直接访问'},
//							{value:310, name:'邮件营销'},
//							{value:234, name:'联盟广告'},
//							{value:135, name:'视频广告'},
//							{value:1548, name:'搜索引擎'}
						//]
					}
				]
			};
		
			// 为echarts对象加载数据 
			myChart.setOption(option); 
		}
	);
	
	}
};