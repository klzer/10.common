// JavaScript Document
$(function () {
//饼图	
	var ZylyPTChart={
		ptData :[
                ['火狐', 672, 45.0],
                ['IE', 120, 26.8],
				['Chrome', 68, 0.7],				
                ['Safari', 10, 8.5],
                ['Opera', 125, 6.2],
                ['其他', 143, 12.8],
				],		
				
		doChart : function(){
			$('#zylyPT').highcharts({
				chart: {
					plotBackgroundColor: null,
					plotBorderWidth: null,
					plotShadow: false
				},
				title: {
					text: ''
				},
				tooltip: {
					pointFormat: '{series.name}: {point.total}(<b>{point.percentage:.1f}%</b>)'
				},
				credits: {
					enabled:false
				},
				exporting: {
					enabled:false
				},
				plotOptions: {
					pie: {
						allowPointSelect: true,
						cursor: 'pointer',
						dataLabels: {
							enabled: true,
							color: '#000000',
							connectorColor: '#000000',
							format: '<b>{point.name}</b>:{point.total}({point.percentage:.1f} %)',
							enabled: false
						}
					}
				},
				series: [{
					type: 'pie',
					name: '总浏览量',
					data:  ZylyPTChart.ptData
				}]
			});
		}		
				
	}
	ZylyPTChart.doChart();
	
//折线图	
	var ZylyChart={
		
		xdata : [ 7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2,7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 16.6, 14.2, 21.5, 25.2],
		
		ydata : [ 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 16.6, 14.2, 10.3, 6.6, 4.8,23.3, 18.3, 13.9, 9.6,23.3, 18.3, 13.9, 9.6, 18.2, 21.5, 25.2,7.0, 6.9],
		
		MAX: 23,
		
		doChart : function(){
			$('#zylyZX').highcharts({
				chart: {
					type: 'spline'
				},
				title: {
					text: ''
				},
				legend: {
					align: 'left',
					verticalAlign: 'top',
					x: 25,
					y: 0
				},
				subtitle: {
					text: ''
				},
				credits: {
					enabled:false
				},
				exporting: {
					enabled:false
				},
				xAxis: {
					categories: ['00:00', '01:00', '02:00', '03:00', '04:00', '05:00','06:00', '07:00', '08:00', '09:00', '10:00', '11:00','12:00', '13:00', '14:00', '15:00', '16:00', '17:00','18:00', '19:00', '20:00', '21:00', '22:00', '23:00'],
					tickmarkPlacement:'on',
					gridLineWidth:1,
					overflow:'undefined',
					labels:{ 
						step:2
					} ,
					min:0,
					max:ZylyChart.MAX
					
				},
				yAxis: {
					title: {
						text: ''
					},
					labels: {
						formatter: function() {
							return this.value
						}
					},
					type:'linear'
				},
				tooltip: {
					crosshairs: false,
					shared: true
				},
				colors: ['#fc651e'],
				series: [{
					name: '浏览量(PV)',
					
					marker: {
						symbol: 'circle',
						radius: 3,
						lineColor: '#666666',
						lineWidth: 1,
						fillColor: '#fc651e',
						lineColor: '#fc651e'
					},
					
					data: ZylyChart.xdata
		
				}]
			});
		}
	};
	
    ZylyChart.doChart();
	
});		
