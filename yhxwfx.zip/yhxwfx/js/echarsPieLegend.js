// JavaScript Document

var echartsPie={
		
	doChart : function(id,legendData,pieData1,pieName1){

	require.config({
			paths: {
				echarts: '../js'
			}
		});
	
	require(
		[
			'echarts',
			'echarts/chart/pie' // 使用饼图就加载pie模块，按需加载
		],
		function (ec) {
			// 基于准备好的dom，初始化echarts图表
			var myChart = ec.init(document.getElementById(id)); 
			
			option1 = {
				title : {
					text: '',
					subtext: '',
					x:'center'
				},			
				tooltip : {
					trigger: 'item',
					axisPointer: {
						type:'shadow'
					},					
					formatter: "{a} <br/>{b} : {c} ({d}%)",
					position:function(p){
						var piex = p[0];
						var piey = p[1];
						var piedw = $('#dyfbPT').width();
						var piew = $('.echarts-tooltip').width();
						var pieh = $('.echarts-tooltip').height();
						if(piex>piedw/2){
							var piex_ = piex-piew-23;
							var piey_ = piey + pieh;
							return [piex_,piey_];
							}else{
								piey = piey + pieh;
								return [piex,piey];
							}				
							return [piex,piey]		
					}				
				},
				legend: {
					show:false,
					orient : 'vertical',
					data:legendData
				},
				toolbox: {
					show : false,
					feature : {
						mark : {show: true},
						dataView : {show: true, readOnly: false},
						magicType : {
							show: true, 
							type: ['pie', 'funnel'],
							option: {
								funnel: {
									x: '25%',
									width: '50%',
									funnelAlign: 'left',
									max: 1548
								}
							}
						},
						restore : {show: true},
						saveAsImage : {show: true}
					}
				},
				color:['#8b8db3','#ff8d78','#8dd7b5','#ffd760','#fff3b5','#4ec5c7','#97ed70','#dbf976','#df9dd7','#fb6e87'],
				calculable : false,
				series : [
					{
						name: pieName1,
						type:'pie',
						radius : '64%',
						center: ['32%', '50%'],	
						
						legendHoverLink:true,				
						itemStyle : {
							normal : {
								label : {
									show : false
								},
								labelLine : {
									show : false
								}
							},
							emphasis : {
								label : {
									show : false,
									position : 'center',
									textStyle : {
										fontSize : '30',
										fontWeight : 'bold'
									}
								}
							}
						},
						data: pieData1
					},{
						name: pieName1,
						type: 'map',
						mapType: 'china',
						roam: false,
						mapLocation:{
							"x": "left",
    						"y": "center"	
						},
						itemStyle:{
							normal:{label:{show:false}},
							emphasis:{label:{show:false}}
						},
						data:pieData1
					}
				]
			};
		
			// 为echarts对象加载数据 
			myChart.setOption(option1); 
		}
		
	);
	
	}
};