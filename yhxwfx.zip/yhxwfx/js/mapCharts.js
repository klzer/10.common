// JavaScript Document

var echartsMap={
		
	doChart : function(){

	require.config({
        paths: {
            echarts: '../js'
        }
    });
    
    require(
        [
            'echarts',
            'echarts/chart/map'
        ],
        function (ec) {
            var myChart = ec.init(document.getElementById('dyfbMap')); 
			//data1 供应商值
			 var data1 = [                
							{name: '福建',value: 100},
							{name: '辽宁',value: 2},
							{name: '黑龙江',value: 3},
							{name: '广东',value: 4},
							{name: '北京',value: 5},
							{name: '天津',value: 1}
							
						];
						
			var name1 = '访客数';
			 
			 option = {
				title : null,				
				legend:null	,
			  	dataRange: {
				  show:false,
					min: 0,
					max: 2500,
					x: 'center',
					y: 'top',
					text:['高','低'],           // 文本，默认为数值文本
					calculable : false
				}, 
			   series : [
					{
						name: name1,
						type: 'map',
						mapType: 'china',
						roam: false,
						mapLocation:{
							"x": "left",
    						"y": "center"	
						},
						itemStyle:{
							normal:{label:{show:false}},
							emphasis:{label:{show:false}}
						},
						data:data1
					}
				],
				tooltip : {	
					trigger: 'item',
					enterable: true,
					formatter: "{a} <br/>{b} : {c} ",
					position:function(p){
						var x = p[0];
						var y = p[1];
						var dw = $('#dyfbMap').width();
						var w = $('.echarts-tooltip').width();
						var h = $('.echarts-tooltip').height();
						if(x>dw/2){
							var x_ = x-w-23;
							var y_ = y - h;
							return [x_,y_];
							}else{
								y = y + h;
								return [x,y];
							}				
							return [x,y]		
					}						
				}
			};
			
			// 为echarts对象加载数据 
			   myChart.setOption(option);  

        }
    );
	
	
	
	}
};










   
