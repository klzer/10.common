// JavaScript Document

//折线图
var splineChart={
		
	doChart : function(id,data1,data2,name1,name2,color1,color2,Xaxis,Colors,Min,Max,Step){
		$('#'+id).highcharts({
			chart: {
				type: 'spline'
			},
			title: {
				text: ''
			},
			legend: {
				align: 'left',
				verticalAlign: 'top',
				x: 25,
				y: 0
			},
			subtitle: {
				text: ''
			},
			credits: {
				enabled:false
			},
			exporting: {
				enabled:false
			},
			xAxis: {
				categories: Xaxis,
				tickmarkPlacement:'on',
				gridLineWidth:1,
				overflow:'undefined',
				labels:{ 
					step:Step
				} ,
				min:Min,
				max:Max
				
			},
			yAxis: {
				title: {
					text: ''
				},
				labels: {
					formatter: function() {
						return this.value
					}
				},
				type:'linear'
			},
			tooltip: {
				crosshairs: false,
				shared: true
			},
			colors: Colors,
			series: [{
				name: name1,
				
				marker: {
					symbol: 'circle',
					radius: 3,
					lineColor: '#666666',
					lineWidth: 1,
					fillColor: color1,
					lineColor: color1
				},
				
				data: data1
	
			},{
				name: name2,
				marker: {
					symbol: 'circle',
					radius: 3,
					lineColor: '#666666',
					lineWidth: 1,
					fillColor: color2,
					lineColor: color2
				},
				data: data2
			}]
		});
	}
};