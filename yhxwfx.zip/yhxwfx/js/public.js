// JavaScript Document

//拖拽窗口 重新计算iframe宽高

	window.onresize = function (){
		var winHeight = $(document).height();	
		var leftAll = $(".leftAll").height();		
		if(leftAll<=winHeight){
			$(".leftAll").height(winHeight);	
			$(".rightAll").height(winHeight);	
		}else{
			$(".rightAll").height(leftAll);	
			$(".leftAll").height(winHeight);
		}
	}


$(function(){
	
	var winHeight = $(document).height();	
	var leftAll = $(".leftAll").height();		
	if(leftAll<=winHeight){
		$(".leftAll").height(winHeight);	
		$(".rightAll").height(winHeight);	
	}else{
		$(".rightAll").height(leftAll);	
		$(".leftAll").height(winHeight);
	}


	var winHeight = $(window).height();	
	var rightAllH = $(".rightAll").height();		
	if(rightAllH<=winHeight){
		$(".rightAll").height(winHeight-45);	
		$(".leftAll").height(winHeight-71);	
	}else{
		$(".rightAll").height(rightAllH);	
		$(".leftAll").height(rightAllH-26);
	}
	
	//select样式
	$(".btn_select").click(function(){		
		$(this).find("select").change(function() {		
		var option = $(this).find("option:selected");
		var selv = option.val();
		var selt = option.text();
		$(this).prev("span:eq(0)").html(selt);
		})
	})	
	//左侧导航展开折叠
	$(".nav li").click(function(){
		//$(this).find("div").show();
		//$(this).siblings("li").find("div").hide();
		var Show = $(this).find("div").css("display");
		if(Show=='none'){
			$(this).find("div").css("display",'block');
		}else{
			$(this).find("div").css("display",'none');	
		}
	})
	
	$(".date span").click(function(){
		$(this).addClass("hover").siblings("span").removeClass("hover");
	})
		
	//筛选条件
	$(".filtrateSelect .cur_select").click(function(){
		if($(this).next(".filtrate").css('display')=='none'){
			$(this).next(".filtrate").show();
		}else{
			$(this).next(".filtrate").hide();	
		}	
	})
	
	//复选选择筛选条件	
	$("input[name='filtrate']").click(function(){
		var inputVal = $(this).val();
		var spanTxt = '<span>'+inputVal+'</span><i class="del" onclick="delFiltrate(this)"></i>';	
		var TEXT = $("#filtrateInfo").html();
		var checked = this.checked;
		if($("input[name='filtrate']:checked").length >= 2)
		{
			$("input[name='filtrate']").attr('disabled','disabled');			
		}else{
			$("input[name='filtrate']").removeAttr('disabled');	
		}				
		if(checked){
			$("input[name='filtrate']:checked").removeAttr('disabled');	
			if(TEXT.toLowerCase().indexOf(spanTxt.toLowerCase())==-1){//判断主菜单是否有相同的菜单\
				$("#filtrateInfo").append(spanTxt);	
			}		
		}
		if(!checked){			
			var x = '';
			$("input[name='filtrate']:checked").each(function(){
				x += '<span>'+$(this).val()+'</span><i class="del" onclick="delFiltrate(this)"></i>';		
			});
			$("#filtrateInfo").html(x);						
		}		
	});
	
	//单选选择筛选条件	
	$("input[name='onecheck']").click(function(){
		var inputVal = $(this).val();
		var spanTxt = '<span>'+inputVal+'</span><i class="del" onclick="delOnecheck(this)"></i>';	
		var TEXT = $("#filtrateInfo").html();
		var checked = this.checked;
		if($("input[name='onecheck']:checked").length >= 1)
		{
			$("input[name='onecheck']").attr('disabled','disabled');			
		}else{
			$("input[name='onecheck']").removeAttr('disabled');	
		}				
		if(checked){
			$("input[name='onecheck']:checked").removeAttr('disabled');	
			if(TEXT.toLowerCase().indexOf(spanTxt.toLowerCase())==-1){//判断主菜单是否有相同的菜单\
				$("#filtrateInfo").append(spanTxt);	
			}		
		}
		if(!checked){			
			var x = '';
			$("input[name='onecheck']:checked").each(function(){
				x += '<span>'+$(this).val()+'</span><i class="del" onclick="delOnecheck(this)"></i>';		
			});
			$("#filtrateInfo").html(x);						
		}		
	});
	
		
	// tbale折叠展开
	$(".sh_I").click(function(){
		var showTR = $(this).parents("tr.bg_blue").next("tr");
		if($(this).hasClass("hideI")){
			showTR.hide();
			$(this).removeClass("hideI").addClass("showI");
		}else{
			showTR.show();
			$(this).removeClass("showI").addClass("hideI");
		};
		
	})
	
	//图例鼠标移动
	$(".legend p").mouseenter(function(){
		$(this).addClass("on");		
	}).mouseleave(function(){
		$(this).removeClass("on");
	})
	
})
//表格基偶行样式 开始	
	$(document).ready(function(){  
		$(".tableStyle tr:even").removeClass("odd");  
		$(".tableStyle tr:odd").addClass("odd"); 
		if($(".tableStyle tr").hasClass("bg_blue")){
			$(".tableStyle tr.bg_blue").removeClass("odd");
		} 
	}); 
	

//复选删除筛选条件
function delFiltrate(obj){
	var txt = $(obj).prev("span").html();
	$("input[name='filtrate']").each(function(){
		if(txt == this.value){
			this.checked = false;
			$("input[name='filtrate']").removeAttr('disabled');
		}
	})
	$(obj).prev("span").remove();
	$(obj).remove();			
}

//单选删除筛选条件
function delOnecheck(obj){
	var txt = $(obj).prev("span").html();
	$("input[name='onecheck']").each(function(){
		if(txt == this.value){
			this.checked = false;
			$("input[name='onecheck']").removeAttr('disabled');
		}
	})
	$(obj).prev("span").remove();
	$(obj).remove();			
}
